# Internship-Project
<h2>A Real Estate website using HTML, CSS and JavaScript</h2>
<br/>
<br/>
<img src="Result/1.png" alt="1st">

<br/>
<br/>
<img src="Result/2.png" alt="1st">

<br/>
<br/>
<img src="Result/3.png" alt="1st">

<br/>
<br/>
<img src="Result/4.png" alt="1st">

<br/>

